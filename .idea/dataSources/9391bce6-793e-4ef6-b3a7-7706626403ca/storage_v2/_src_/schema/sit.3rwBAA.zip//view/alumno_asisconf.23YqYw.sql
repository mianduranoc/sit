create view alumno_asisconf as
  select concat(`a`.`apellido`, ' ', `a`.`nombre`) AS `nombre`, `a`.`nc` AS `nc`
  from `sit`.`Tutorado_Grupo` `tg`
         join `sit`.`Alumno` `a`
  where ((`tg`.`nc` = `a`.`nc`) and (`tg`.`grupo` = '5A'))
  order by concat(`a`.`apellido`, ' ', `a`.`nombre`);

