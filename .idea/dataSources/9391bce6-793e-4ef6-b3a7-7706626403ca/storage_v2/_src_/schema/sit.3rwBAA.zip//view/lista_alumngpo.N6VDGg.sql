create view lista_alumngpo as
  select distinct `a`.`nc` AS `nc`, concat(`a`.`apellido`, ' ', `a`.`nombre`) AS `nombre`
  from `sit`.`Alumno` `a`
         join `sit`.`Alumno_Sesion` `als`
         join `sit`.`Sesion` `s`
         join `sit`.`Personal` `p`
         join `sit`.`Tutorado_Grupo` `g`
  where ((`g`.`grupo` = `s`.`grupo`) and (`g`.`nc` = `a`.`nc`) and (`a`.`nc` = `als`.`Alumno_nc`) and
         (`s`.`estado` = 0) and (`als`.`Sesion_id_sesion` = `s`.`id_sesion`) and (`s`.`Personal_rfc` = `p`.`rfc`) and
         (`p`.`rfc` = 'CCCCC') and (`s`.`grupo` = '5A'));

