create view reporte_tutor as
  select `a`.`nc`                                    AS `nc`,
         `tg`.`grupo`                                AS `grupo`,
         concat(`A2`.`nombre`, ' ', `A2`.`apellido`) AS `nombre`,
         `a`.`acreditado`                            AS `acreditado`,
         `a`.`desertor`                              AS `desertor`,
         sum(`S`.`asistencia`)                       AS `asistencias_sesiones`
  from (((((`sit`.`Alumno_Tutoria` `a` join `sit`.`Alumno` `A2` on ((`a`.`nc` =
                                                                     `A2`.`nc`))) join `sit`.`Carrera` `C` on ((
    `A2`.`Carrera_id_carrera` = `C`.`id_carrera`))) join `sit`.`Tutorado_Grupo` `tg` on ((`a`.`nc` =
                                                                                          `tg`.`nc`))) join `sit`.`Alumno_Sesion` `S` on ((
    `A2`.`nc` = `S`.`Alumno_nc`))) join `sit`.`Sesion` `S2` on ((`S`.`Sesion_id_sesion` = `S2`.`id_sesion`)))
  where ((`S`.`asistencia` = 1) and (length(`S2`.`grupo`) < 5))
  group by `a`.`nc`, `tg`.`grupo`, `A2`.`nombre`, `A2`.`apellido`, `a`.`acreditado`, `a`.`desertor`;

