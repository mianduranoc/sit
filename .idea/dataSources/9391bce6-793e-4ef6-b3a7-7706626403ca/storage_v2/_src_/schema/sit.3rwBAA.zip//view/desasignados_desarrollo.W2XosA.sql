create view desasignados_desarrollo as
  select concat(`P2`.`nombre`, ' ', `P2`.`apellido`) AS `nombre_completo`,
         `u`.`rfc`                                   AS `rfc`,
         `P`.`idPuesto`                              AS `idPuesto`,
         `P`.`nombre`                                AS `nombre`,
         `D`.`id_depto`                              AS `id_depto`,
         `D`.`nombre_depto`                          AS `nombre_depto`,
         `u`.`puesto_tutor`                          AS `id_interno`
  from (((`sit`.`usuarios` `u` join `sit`.`Personal` `P2` on ((`u`.`rfc` = `P2`.`rfc`))) join `sit`.`Puesto` `P` on ((
    `P2`.`Puesto_idPuesto` = `P`.`idPuesto`))) join `sit`.`Departamento` `D` on ((`P2`.`Departamento_id_depto` =
                                                                                  `D`.`id_depto`)))
  where ((isnull(`u`.`puesto_tutor`) or `u`.`puesto_tutor` in (select `sit`.`puesto_interno`.`idpuesto_interno`
                                                               from `sit`.`puesto_interno`
                                                               where (`sit`.`puesto_interno`.`nombre` = 'Tutor'))) and
         (`P`.`idPuesto` <> 3));

