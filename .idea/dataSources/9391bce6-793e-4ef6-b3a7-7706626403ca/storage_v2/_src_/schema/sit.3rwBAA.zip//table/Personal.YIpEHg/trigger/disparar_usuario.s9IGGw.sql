create trigger disparar_usuario
  after INSERT
  on Personal
  for each row
  INSERT INTO usuarios (rfc,correo_enviado,primera_vez) VALUES (NEW.rfc,0,1);

