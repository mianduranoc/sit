create view asistencia_sesion as
  select distinct `sit`.`Alumno_Sesion`.`Alumno_nc`        AS `Alumno_nc`,
                  `sit`.`Alumno_Sesion`.`Sesion_id_sesion` AS `Sesion_id_sesion`
  from (`sit`.`Alumno_Sesion` join `sit`.`Sesion` on ((
    (`sit`.`Sesion`.`estado` = 0) and (`sit`.`Alumno_Sesion`.`Sesion_id_sesion` = `sit`.`Sesion`.`id_sesion`) and
    (`sit`.`Sesion`.`id_sesion` = '39'))));

