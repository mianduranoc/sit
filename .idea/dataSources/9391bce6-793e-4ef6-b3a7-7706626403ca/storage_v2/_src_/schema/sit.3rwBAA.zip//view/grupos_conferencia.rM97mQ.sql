create view grupos_conferencia as
  select distinct `c`.`id_conferencia` AS `id_conferencia`,
                  `t`.`descripcion`    AS `evento`,
                  `c`.`nombre`         AS `titulo`,
                  `c`.`fecha_hora`     AS `fecha`,
                  `c`.`Hora`           AS `hora`,
                  `l`.`nombre`         AS `lugar`,
                  `cg`.`id_grupo`      AS `grupo`
  from `sit`.`Conferencia` `c`
         join `sit`.`lugares` `l`
         join `sit`.`Tutorado_Conferencia` `tc`
         join `sit`.`Grupo_Conferencia` `cg`
         join `sit`.`Tipo_Conferencia` `t`
  where ((`c`.`id_conferencia` = `tc`.`id_conferencia`) and (`l`.`id_lugar` = `c`.`lugar`) and
         (`t`.`id_tipo_conf` = `c`.`Tipo_Conferencia_id_tipo_conf`) and
         (`cg`.`Conferencia_id_conferencia` = `c`.`id_conferencia`));

