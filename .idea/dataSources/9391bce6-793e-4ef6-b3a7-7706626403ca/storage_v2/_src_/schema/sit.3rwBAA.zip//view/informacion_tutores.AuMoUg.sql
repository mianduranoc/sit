create view informacion_tutores as
  select `u`.`rfc`              AS `rfc`,
         `u`.`contrasena`       AS `contrasena`,
         `P`.`nombre`           AS `nombre`,
         `P`.`apellido`         AS `apellido`,
         `P`.`correo`           AS `correo`,
         `P`.`telefono`         AS `telefono`,
         `i`.`idpuesto_interno` AS `idpuesto_interno`,
         `i`.`nombre`           AS `puesto_tutor`,
         `D`.`id_depto`         AS `id_depto`,
         `D`.`nombre_depto`     AS `Departamento`,
         `P2`.`idPuesto`        AS `idPuesto`,
         `P2`.`nombre`          AS `puesto`
  from ((((`sit`.`usuarios` `u` join `sit`.`Personal` `P` on ((`u`.`rfc` =
                                                               `P`.`rfc`))) join `sit`.`puesto_interno` `i` on ((
    `u`.`puesto_tutor` = `i`.`idpuesto_interno`))) join `sit`.`Departamento` `D` on ((`P`.`Departamento_id_depto` =
                                                                                      `D`.`id_depto`))) join `sit`.`Puesto` `P2` on ((
    `P`.`Puesto_idPuesto` = `P2`.`idPuesto`)));

