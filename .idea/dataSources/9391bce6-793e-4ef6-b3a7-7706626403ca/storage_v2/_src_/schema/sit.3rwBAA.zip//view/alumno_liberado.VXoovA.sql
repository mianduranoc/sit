create view alumno_liberado as
  select concat(`a`.`apellido`, ' ', `a`.`nombre`) AS `nombre`, `a`.`nc` AS `nc`
  from `sit`.`Alumno_Tutoria` `tg`
         join `sit`.`Alumno` `a`
  where ((`tg`.`nc` = `a`.`nc`) and (`tg`.`acreditado` = 1) and (`tg`.`desertor` = 0));

