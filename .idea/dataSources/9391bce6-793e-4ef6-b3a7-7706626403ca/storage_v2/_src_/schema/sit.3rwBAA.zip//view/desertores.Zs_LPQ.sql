create view desertores as
  select `t`.`id_grupo` AS `id_grupo`, `t`.`rfc` AS `rfc`, count(`a`.`desertor`) AS `desertor`
  from ((`sit`.`tutor_tutorado` `t` join `sit`.`Tutorado_Grupo` `tg` on ((`tg`.`grupo` =
                                                                          `t`.`id_grupo`))) join `sit`.`Alumno_Tutoria` `a` on ((
    `a`.`nc` = `tg`.`nc`)))
  where (`a`.`desertor` > 0)
  group by `t`.`id_grupo`, `t`.`rfc`;

