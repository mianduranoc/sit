create view lista_asisgrupo as
  select concat(`a`.`apellido`, ' ', `a`.`nombre`) AS `nombre`, `a`.`nc` AS `nc`
  from `sit`.`Alumno` `a`
         join `sit`.`Alumno_Sesion` `als`
  where ((`als`.`asistencia` = 1) and (`als`.`Alumno_nc` = `a`.`nc`) and (`als`.`Sesion_id_sesion` = '84'));

