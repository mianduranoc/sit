create view total as
  select `t`.`id_grupo`                            AS `id_grupo`,
         `t`.`rfc`                                 AS `rfc`,
         sum(`a`.`acreditado`)                     AS `acreditado`,
         sum(`a`.`desertor`)                       AS `desertor`,
         count(`a`.`acreditado`)                   AS `total`,
         concat(`P`.`nombre`, ' ', `P`.`apellido`) AS `nombre`,
         `C`.`nombre`                              AS `carrera`
  from (((((`sit`.`tutor_tutorado` `t` join `sit`.`Tutorado_Grupo` `tg` on ((`tg`.`grupo` =
                                                                             `t`.`id_grupo`))) join `sit`.`Alumno_Tutoria` `a` on ((
    `a`.`nc` = `tg`.`nc`))) join `sit`.`Personal` `P` on ((`a`.`rfc` = `P`.`rfc`))) join `sit`.`Alumno` `A2` on ((
    `a`.`nc` = `A2`.`nc`))) join `sit`.`Carrera` `C` on ((`A2`.`Carrera_id_carrera` = `C`.`id_carrera`)))
  group by `t`.`id_grupo`, `t`.`rfc`, `P`.`nombre`, `P`.`apellido`, `C`.`nombre`;

