create view informacion_conferencias as
  select `c`.`id_conferencia`    AS `id_conferencia`,
         `c`.`nombre`            AS `nombre`,
         `c`.`descripcion`       AS `descripcion`,
         `c`.`limite_asistentes` AS `limite_asistentes`,
         `c`.`fecha_hora`        AS `fecha_hora`,
         `c`.`Hora`              AS `Hora`,
         `l`.`id_lugar`          AS `id_lugar`,
         `l`.`nombre`            AS `lugar`,
         `l`.`capacidad`         AS `capacidad`,
         `C2`.`descripcion`      AS `tipo_desc`,
         `c`.`ocupados`          AS `ocupados`
  from ((`sit`.`Conferencia` `c` join `sit`.`Tipo_Conferencia` `C2` on ((`c`.`Tipo_Conferencia_id_tipo_conf` =
                                                                         `C2`.`id_tipo_conf`))) join `sit`.`lugares` `l` on ((
    `c`.`lugar` = `l`.`id_lugar`)));

